## Module <custom_receipts_for_pos>

#### 05.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for POS Receipt Design

#### 17.04.2024
#### Version 17.0.1.0.1
##### BUGFIX
- Fixed the error in printing the receipt

#### 15.06.2024
#### Version 17.0.1.0.2
##### BUGFIX
- Fix the receipt selection for each point of sales

#### 15.06.2024
#### Version 17.0.1.0.3
##### BUGFIX
- Move the configuration to select the receipt from configuration settings to POS configuration
